varying vec4 pos;

void main()
{
  gl_FragColor= vec4(pos.x,pos.y,pos.z,0.5);
}