#version 330 core

uniform sampler2D myTexture;
//varying vec2 texCoord;

in vec4 pos;

out vec4 FragColor;

void main()
{
 // gl_FragColor = texture2D(myTexture,texCoord).gbra;

 FragColor= vec4(pos.x,pos.y,pos.z,0.5);
}