#include <string.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <time.h>

#include <SOIL.h>

#define PI 3.14159

using namespace std;

bool WireFrame= false;
float i =0;
float t=0;
const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

    float xpos =0;
    float ypos =0;

    float Tx =0.0;
    float Ty =0.0;
    float Wwidth,Wheight;

    clock_t startTime;

    GLuint tex1;
    GLuint gunT;
    GLuint tex[6];

    int RotateX=0;
    int RotateY=0;

    float mouseX;
    float mouseY;

    float depth =300.00;
    int dir = 1;

    GLdouble realMX, realMY, realMZ;

    bool shoot= false;

void gunQuad(GLuint &texture)
{
     glDisable(GL_LIGHTING);
    glPushMatrix();
    glScaled(0.5,0.5,0.5);
    glTranslated(0.0,-8.0,0.0);
    glBindTexture(GL_TEXTURE_2D,texture);

glBegin(GL_QUADS);
 glNormal3f(0.0f, 0.0f, -1.0f); // Normal Back Face
 glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, 1.0f, -1.0f); // Bottom Right Of The Texture and Quad
 glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f); // Top Right Of The Texture and Quad
 glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f); // Top Left Of The Texture and Quad
 glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, 1.0f, -1.0f); // Bottom Left Of The Texture and Quad
 glEnd();
    glPopMatrix();

     glEnable(GL_LIGHTING);
}

void drawBullet(float srcX, float srcY,float srcZ, float dstX, float dstY, float dstZ)
{
    float xpos, ypos,zpos;
    glDisable(GL_TEXTURE_2D);

    if(t>=1){t=0; shoot = false;}

    if(shoot)
    {

    if(clock()-startTime >10.0)
    {
    t+=0.008;startTime= clock();
    }
    xpos = srcX +t*(dstX - srcX);
    ypos = srcY +t*(dstY - srcY);
    zpos = srcZ +t*(dstZ - srcZ);


    glPushMatrix();

    glTranslated(xpos,ypos,zpos);
    glutSolidSphere(0.2,20,20);
    glPopMatrix();

    srcX = xpos;
    srcY = ypos;
    srcZ = zpos;

    }
    glEnable(GL_TEXTURE_2D);
}



/* GLUT callback Handlers */

void TLoad(char* fileName, GLuint &tex)
{
    int width, height;

    unsigned char* image;

    glBindTexture(GL_TEXTURE_2D, tex);

    image = SOIL_load_image(fileName,&width,&height,0,SOIL_LOAD_RGBA); // let soil load image
    if(!image) {cout<< "Image not Found"<<endl;}

    glTexImage2D(GL_TEXTURE_2D, 0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,image);

    SOIL_free_image_data(image);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_NEAREST);

}


static void resize(int width, int height)
{
     double Ratio;

     Wwidth = (float)width;
     Wheight = (float)height;

     Ratio= (double)width /(double)height;

    glViewport(0,0,(GLsizei) width,(GLsizei) height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

 //    glOrtho(-width,width,height,-height,-1.5,1.5);

 	gluPerspective (45.0f,Ratio,0.1f, depth);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

 }

static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(0,0,0.1,0.0,1.0,-100.0,0.0,1.0,0.0);

    if(WireFrame)
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);		//Draw Our Mesh In Wireframe Mesh
	else
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);		//Toggle WIRE FRAME

        glBindTexture(GL_TEXTURE_2D, tex1);
		glPushMatrix();

 glDisable(GL_LIGHTING);
 glTranslated(0,0,0);
 glRotated(RotateX,1,0,0);
 glRotated(RotateY,0,1,0);
 //glRotated(RotateZ,0,0,1);
 glScalef(100.0,100.0,100.0);

  glBindTexture(GL_TEXTURE_2D, tex[0]);
 glBegin(GL_QUADS);
 glNormal3f(0.0f, 0.0f, 1.0f); // Normal Front Face
 glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, 1.0f, 1.0f); // Bottom Left Of The Texture and Quad
 glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, 1.0f, 1.0f); // Bottom Right Of The Texture and Quad
 glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, -1.0f, 1.0f); // Top Right Of The Texture and Quad
 glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, -1.0f, 1.0f); // Top Left Of The Texture and Quad
 glEnd();

  glBindTexture(GL_TEXTURE_2D, tex[1]);
  glBegin(GL_QUADS);
 glNormal3f(0.0f, 0.0f, -1.0f); // Normal Back Face
 glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, 1.0f, -1.0f); // Bottom Right Of The Texture and Quad
 glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f); // Top Right Of The Texture and Quad
 glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f); // Top Left Of The Texture and Quad
 glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, 1.0f, -1.0f); // Bottom Left Of The Texture and Quad
 glEnd();

  glBindTexture(GL_TEXTURE_2D, tex[2]);
  glBegin(GL_QUADS);
 glNormal3f(0.0f, 1.0f, 0.0f); // Normals Top Face
 glTexCoord2f(0.0f, 1.0f); glVertex3f(1.0f, 1.0f, -1.0f); // Top Left Of The Texture and Quad
 glTexCoord2f(0.0f, 0.0f); glVertex3f(1.0f, 1.0f, 1.0f); // Bottom Left Of The Texture and Quad
 glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, 1.0f, 1.0f); // Bottom Right Of The Texture and Quad
 glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, 1.0f, -1.0f); // Top Right Of The Texture and Quad
 glEnd();

  glBindTexture(GL_TEXTURE_2D, tex[3]);
  glBegin(GL_QUADS);
 glNormal3f(0.0f, -1.0f, 0.0f); // Bottom Face
 glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, 1.0f); // Top Right Of The Texture and Quad
 glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, 1.0f); // Top Left Of The Texture and Quad
 glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f); // Bottom Left Of The Texture and Quad
 glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f); // Bottom Right Of The Texture and Quad
 glEnd();

  glBindTexture(GL_TEXTURE_2D, tex[4]);
  glBegin(GL_QUADS);
 glNormal3f(1.0f, 0.0f, 0.0f); // Right face
 glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, 1.0f, -1.0f); // Bottom Right Of The Texture and Quad
 glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f); // Top Right Of The Texture and Quad
 glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, 1.0f); // Top Left Of The Texture and Quad
 glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, 1.0f, 1.0f); // Bottom Left Of The Texture and Quad
 glEnd();

  glBindTexture(GL_TEXTURE_2D, tex[5]);
 glBegin(GL_QUADS);
 glNormal3f(-1.0f, 0.0f, 0.0f); // Left Face
 glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, 1.0f, -1.0f); // Bottom Left Of The Texture and Quad
 glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, 1.0f, 1.0f); // Bottom Right Of The Texture and Quad
 glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, 1.0f); // Top Right Of The Texture and Quad
 glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f); // Top Left Of The Texture and Quad
 glEnd();
 glPopMatrix();

 glEnable(GL_LIGHTING);

 glPushMatrix();
		 glBindTexture(GL_TEXTURE_2D, tex1);
		 glTranslated(Tx,Ty, -100.0);
		 glutSolidTeapot(2.0);
 glPopMatrix();

 gunQuad(gunT);

 drawBullet(0.0,-4.0,-10.0, realMX,realMY,-100.0);

    // your code here
    glutSwapBuffers();
}


static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 27 :
        case 'q':
            exit(0);
            break;

	  case 'w':
		WireFrame =!WireFrame;
	       break;
    }
}

void Specialkeys(int key, int x, int y)
{
    switch(key)
    {
    case GLUT_KEY_UP:
    break;

        case GLUT_KEY_DOWN:
    break;

        case GLUT_KEY_LEFT:
            Tx = Tx - 5;
            //cout<< Tx <<endl;
    break;

        case GLUT_KEY_RIGHT:
             Tx = Tx + 5;
             //cout<< Tx <<endl;
    break;
   }
  glutPostRedisplay();
}


static void idle(void)
{
    // Use parametric equation with t increment for xpos and y pos
    // Don't need a loop
    if((clock() - startTime)>10){

    if (shoot){
        t+=0.008;
    }

        Tx += dir*0.05;
        if(Tx  > 60)dir=-1;
        if(Tx < -60) dir =1;
        startTime = clock();
    }


    glutPostRedisplay();

}

void mouseMove(int x, int y)
{
    static float prev_x =0.0;
    static float prev_y =0.0;

    prev_x = (float)x-prev_x;
    prev_y = (float)y-prev_y;

    if((abs((int)prev_x)>15)||(abs((int)prev_y)>15))
    {
        prev_x = (float)x;
        prev_y = (float)y;
        return;
    }

    RotateY = (RotateY+(int)prev_x)%360;
    RotateX = (RotateX+(int)prev_y)%360;

}

void getRealMouse(int x, int y)
{
    GLint viewPort[4];
    GLdouble modelView[16];
    GLdouble projectionMat[16];
    GLfloat winX, winY, winZ;


    glGetDoublev(GL_PROJECTION_MATRIX, projectionMat);
    glGetDoublev(GL_MODELVIEW_MATRIX,modelView);
    glGetIntegerv(GL_VIEWPORT,viewPort);

    winX = (GLfloat)x;
    winY = (GLfloat)viewPort[3]-(GLfloat)y;
    glReadPixels(x,int(winY),1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&winZ);

    gluUnProject(winX,winY,winZ,modelView,projectionMat,viewPort,&realMX,&realMY,&realMZ);

    //cout<<"mouseX is "<<realMX<<" mouseY is "<<realMY<<" mouseZ is "<<realMZ<<endl;
}




void mouse(int btn, int state, int x, int y){

    float scale = 55*(Wwidth/Wheight);
    cout<<"Actual X "<<x<<" Actual Y "<<y<<endl;

    switch(btn){
        case GLUT_LEFT_BUTTON:

        if(state==GLUT_DOWN){

        shoot = true;
        t=0.0;

        //mouseX= (float)(x-Wwidth/2)/scale;
        //mouseY= (float)(Wheight/2-y)/scale;

        getRealMouse(x,y);

        cout<<"Mouse X is "<<mouseX<<" Mouse Y is "<< mouseY<<endl;

               // get new mouse coordinates for x,y
               // use scale to match right
            }
            break;
    }
     glutPostRedisplay();
};



static void init(void)
{
 //   glEnable(GL_CULL_FACE);
 //   glCullFace(GL_BACK);

    glClearColor(0.5f, 0.5f, 1.0f, 0.0f);                 // assign a color you like

    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);

    glEnable(GL_DEPTH_TEST);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glShadeModel(GL_SMOOTH);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);

    glEnable(GL_TEXTURE_2D);
    glGenTextures(1,&tex1);
    glGenTextures(1,&gunT);
    glGenTextures(6,tex);

    TLoad("images/flower.jpeg",tex1);
    TLoad("images/gun.png",gunT);

    TLoad("images/front.jpg",tex[0]);
    TLoad("images/back.jpg",tex[1]);
    TLoad("images/top.jpg",tex[2]);
    TLoad("images/bottom.jpg",tex[3]);
    TLoad("images/left.jpg",tex[4]);
    TLoad("images/right.jpg",tex[5]);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    glutSetCursor(GLUT_CURSOR_CROSSHAIR);
  //  glutSetCursor(GLUT_CURSOR_NONE);

   startTime =clock();
}

/* Program entry point */

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);

    glutInitWindowSize(800,600);
    glutInitWindowPosition(0,0);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("Project Assignment 2");
    init();
    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(mouseMove);
    glutKeyboardFunc(key);
    glutSpecialFunc(Specialkeys);

    glutIdleFunc(idle);

    glutMainLoop();

    return EXIT_SUCCESS;
}
