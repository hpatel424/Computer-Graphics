#include "GLScene.h"
#include <GLlight.h>
#include <Model.h>
#include<Inputs.h>
#include <parallax.h>
#include <player.h>
#include <enemies.h>
#include <checkCollision.h>

Model *myFirstModel = new Model();
Inputs *KbMs = new Inputs();
parallax* prLX = new parallax();
parallax* prLX2 = new parallax();
player* ply = new player();
enemies en[20];
checkCollision* hit = new checkCollision();

GLScene::GLScene()
{
    //ctor
    screenHeight = GetSystemMetrics(SM_CYSCREEN);
    screenWidth = GetSystemMetrics(SM_CXSCREEN);
}

GLScene::~GLScene()
{
    //dtor
}
int GLScene::drawScene()
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    glColor3f(1.0,0.0,0.0);
    glPushMatrix();
    glScaled(3.33,3.33,1.0);
    prLX->drawSquare(screenWidth, screenHeight);
    //prLX->scroll(true,"x",0.0005);    //comment this out so the background wont run automatically
    glPopMatrix();

    glPushMatrix();
    ply->drawPlayer();
    glPopMatrix();

    //for the enemy jumping
    if(ply->jumping == true)
    {
        ply->update();
    }

    for(int i =0; i <7;i++)
    {
            if(hit->isRadialCollision(ply->pPos.x,en[i].ePos.x, ply->pPos.y,  en[i].ePos.y, 0.20,0.11)){
                //en[i].action = en[i].ROLLR;
                en[i].draw = false;
                //en[i].eSpeed.x = 0.01;
                //en[i].ePos.x += 0.5;
            }

       else{  //when it reach the end of the screen both sides. It comes back
            //en[i].action = en[i].WALKL;
            if(en[i].ePos.x < -2.0){
                    //en[i].draw = true;
                    en[i].draw = false;
                     //en[i].action = en[i].WALKL;

               // en[i].ePos.x = 0.7;
                //en[i].action = en[i].WALKL;
            }


            /*if(en[i].ePos.x  < -2.0)
            {
            en[i].action = en[i].WALKR;

            }
            else if(en[i].ePos.x > 2.0)
            {
            en[i].action = en[i].WALKL;
            }*/
        }
        en[i].drawEnemy();

    }
    glPopMatrix();
}

int GLScene::GLinit()
{
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glClearColor(0.0f,0.0f,0.0f,0.0f);

    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLlight Light (GL_LIGHT0);
    Light.setLight(GL_LIGHT0);

    glEnable(GL_TEXTURE_2D);

    prLX->initParallax("images/art.png");

    ply->playerInit("images/guy.png", 6, 4);

    //en[0].enemyTexture("images/mon.png");

    for(int i =0; i <10; i++)
    {
        //en[i].initEnemy(en[0].tex,7,2);  //to avoid loading same image for all enemies
        en[i].placeEnemy(vec3{(float)rand()/(float)(RAND_MAX)*5-2.5, -0.5,-2.5});   //x, y, z value
        en[i].eSize.x = en[i].eSize.y = float(rand()%12)/55.0;  //the size of the object
    }


    return true;

}

void GLScene::GLresize(GLsizei width, GLsizei height)
{
    screenWidth = width;
    screenHeight = height;
    float ratio = (float)width/(float)height;
    glViewport(0,0,width,height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0,ratio,0.1,100);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int GLScene::winMsg(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    KbMs->wParam = wParam;
    switch(uMsg)
    {
    case WM_KEYDOWN:

        KbMs->keyPressed(myFirstModel);
        KbMs->keyEnv(prLX,0.005);
        KbMs->keyPlayer(ply);
        break;
    case WM_KEYUP:
        KbMs->keyUp();
        ply->actions(ply->IDLE);
        break;
    case WM_LBUTTONDOWN:
        KbMs->mouseButtonDown(myFirstModel, LOWORD(lParam), HIWORD(lParam));
        break;
    case WM_RBUTTONDOWN:
        KbMs->mouseButtonDown(myFirstModel, LOWORD(lParam), HIWORD(lParam));
        break;
    case WM_MBUTTONDOWN:
        KbMs->mouseButtonDown(myFirstModel, LOWORD(lParam), HIWORD(lParam));
        break;
    case WM_LBUTTONUP:
    case WM_RBUTTONUP:
    case WM_MBUTTONUP:
        KbMs->mouseBottonUp();
        break;
    case WM_MOUSEMOVE:
        KbMs->mouseMove(myFirstModel, LOWORD(lParam), HIWORD(lParam));
        break;
    case WM_MOUSEWHEEL:
        KbMs->mouseWheel(myFirstModel, (double)GET_WHEEL_DELTA_WPARAM(wParam));
        break;
    }
}
