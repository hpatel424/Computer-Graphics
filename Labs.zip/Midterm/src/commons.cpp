#include "commons.h"
#include <math.h>
#define GRAVITY 9.81
#define PI 3.14159

commons::commons()
{
    //ctor
}

commons::~commons()
{
    //dtor
}
