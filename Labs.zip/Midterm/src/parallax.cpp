#include "parallax.h"

parallax::parallax()
{
    //ctor
    xmax = 1.0;
    xmin = 0.0;
    ymax = 0.0;
    ymin = 1.0;   //why ymin is 1 instead of 0

    startTime = clock();
}

parallax::~parallax()
{
    //dtor
}
void parallax::drawSquare(float width, float height)
{
    glColor3f(1.0,1.0,1.0);
    bTex->binder(tex);
    glBegin(GL_POLYGON);

    glTexCoord2f(xmin,ymin);
    glVertex3f(-1*width/height, -1, -8.0);   //I dont know what the first parameter means

    glTexCoord2f(xmax,ymin);
    glVertex3f(width/height, -1, -8.0);

    glTexCoord2f(xmax,ymax);
    glVertex3f(width/height, 1, -8.0);

    glTexCoord2f(xmin,ymax);
    glVertex3f(-1*width/height, 1, -8.0);
    glEnd();

}


void parallax::initParallax(char* fileName)
{
    bTex->loadTexture(fileName,tex);
}


void parallax::scroll(bool scrl, string Dir, float speed)
{
    if(scrl){

        if(clock()-startTime > 15){

        if(Dir == "x"){ xmin += speed; xmax += speed;}
        else if(Dir == "-x"){ xmin -= speed; xmax -= speed;}
        else if(Dir == "y"){ ymin -= speed; ymax -= speed;}
        else{ ymin += speed; ymax += speed;}

        startTime = clock();
        }
    }
}
