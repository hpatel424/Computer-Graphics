#include "textureLoader.h"

textureLoader::textureLoader()
{
    //ctor
}

textureLoader::~textureLoader()
{
    //dtor
}
void textureLoader::loadTexture(char* fileName, GLuint& tid)
{
    glGenTextures(1,&tid);
    glBindTexture(GL_TEXTURE_2D, tid);
    image = SOIL_load_image(fileName, &width, &height,0,SOIL_LOAD_RGBA);  //the soil read the image file types for us and image which is a pointer point to it.

    if(!image)
        cout << "No image found" << endl;

    glTexImage2D(GL_TEXTURE_2D,0, GL_RGBA, width, height,0, GL_RGBA,GL_UNSIGNED_BYTE,image); //glTeximage2d is like a bucket that store the picture information inside it.
    SOIL_free_image_data(image);  //after we store the file in the bucket we free the memory

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,GL_REPEAT);

}

void textureLoader::binder(GLuint tid)
{
    glBindTexture(GL_TEXTURE_2D, tid);
}
