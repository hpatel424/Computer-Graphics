#include "player.h"
#define PI 3.14159
#define GRAVITY 9.81

player::player()
{
    //ctor
    verts[0].x = -0.5; verts[0].y = -0.5; verts[0].z = -1.0;
    verts[1].x = 0.5; verts[1].y = -0.5; verts[1].z = -1.0;
    verts[2].x = 0.5; verts[2].y = 0.5; verts[2].z = -1.0;
    verts[3].x = -0.5; verts[3].y = 0.5; verts[0].z = -1.0;

    runSpeed = 0;
    jumpSpeed = 0;
    actionTrigger = IDLE;
    playerDirection = 'R';

    pPos.x = 0;
    pPos.y = -0.3;     //the position of the character x y z
    pPos.z = -2;

    //physics
    jumping = false;
    theta = 30* PI/180.0;
    velocity =50;
    t =0;
    startTime = clock();

}

player::~player()
{
    //dtor
}
void player::drawPlayer()
{
    tLoad->binder(tex);
    glTranslatef(pPos.x,pPos.y,pPos.z);

    glBegin(GL_QUADS);
    glTexCoord2f(xMin,yMax);
    glVertex3f(verts[0].x, verts[0].y, verts[0].z);

    glTexCoord2f(xMax,yMax);
    glVertex3f(verts[1].x, verts[1].y, verts[1].z);

    glTexCoord2f(xMax,yMin);
    glVertex3f(verts[2].x, verts[2].y, verts[2].z);

    glTexCoord2f(xMin,yMin);
    glVertex3f(verts[3].x, verts[3].y, verts[3].z);
    glEnd();

}

void player::playerInit(char* fileName, int vfrm, int hfrm)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);  //to remove the black background from the sprite characters
    vFrames = vfrm;
    hFrames = hfrm;
                                      //ymax >
    xMax = 1.0/(float)vfrm;                // |X|X|X|X|X|X|X|X|X|   //our picture is 9x6. so if we want to get the first character of
    xMin = 0.0;                       //ymin >^ ^                   //the spritesheet we set the coordinate of its frame xMax = 1
    yMax = 1.0/(float)hfrm;           //   xmin xmax                //divided by the number of vertical frame and YMax = 1 divided
    yMin = 0.0;                            // |X|X|X|X|X|X|X|X|X|   //by the number of horizontal frame
    tLoad->loadTexture(fileName, tex);     // ...................

}

void player::actions(acts action)
{
    switch(action)
    {
        case IDLE:
            if(playerDirection == 'R')
            {
            xMax = 1.0/(float)vFrames;    //set the character to the initial position (first frame) when we unpressed the move button
            xMin = 0.0;
            yMax = 1.0/(float)hFrames;
            yMin = 0.0;
            }
            else if(playerDirection == 'L')
            {
            xMin = 1.0/(float)vFrames;    //set the character to the initial position (first frame) when we unpressed the move button
            xMax = 0.0;
            yMax = 1.0/(float)hFrames;
            yMin = 0.0;
            }
            actionTrigger = IDLE;
        break;
        case WALKL:
            if(clock()-startTime > 100){
              if(!jumping)
              {
                if(playerDirection != 'R')
                {
                  float tmp;
                  tmp = xMax;
                  xMax = xMin;
                  xMin = tmp;
                  playerDirection = 'R';
                }

                yMin = 2/(float)hFrames;
                yMax = 3/(float)hFrames;

                xMin += 1/(float)vFrames;
                xMax += 1/(float)vFrames;

                if(xMax > 1)
                {
                    xMax = 1.0/(float)vFrames;
                    xMin = 0.0;
                }
                actionTrigger = WALKR;
              }
            startTime = clock();
            }
        break;
        case WALKR:
            if(clock()-startTime > 100){
                if(!jumping)
                {
                    if(playerDirection!= 'L'){
                    float tmp;
                    tmp = xMax;
                    xMax = xMin;
                    xMin = tmp;
                    playerDirection = 'L';
                }
                    yMin = 2/(float)hFrames;
                    yMax = 3/(float)hFrames;

                    xMin += 1.0/(float)vFrames;
                    xMax += 1.0/(float)vFrames;

                if(xMin > 1)
                {
                xMin = 1.0/(float)vFrames;
                xMax = 0.0;
                }
                actionTrigger = WALKL;
                }
              startTime = clock();
            }
        break;
        case JUMP:
             jumping = true;
             actionTrigger = JUMP;
             break;
    }
}

void player::update()
{
    if(clock()-startTime > 50)
    {
        yMin = 1/(float)hFrames;
        yMax = 2/(float)hFrames;

        pPos.y += (velocity*t*sin(theta)-0.5*GRAVITY*t*t)/700;
            if(playerDirection == 'L')
            {
                if(xMin < 5.0/(float)vFrames)
                {
                xMax += 1.0/(float)vFrames;
                xMin += 1.0/(float)vFrames;
                }
            }
            else
            {
            if(xMax < 5.0/(float)vFrames)
            {
                xMax += 1.0/(float)vFrames;
                xMin += 1.0/(float)vFrames;
            }
        }
        if(pPos.y >= -0.5){
            t += 0.2;
        }
        else{
            t = 0;
            pPos.y = -0.3;;
            actionTrigger = IDLE;
            jumping = false;
            xMin = 1.0/(float)vFrames;
            xMax = 0.0;
            yMin = 0.0;
            yMax = 1/(float)hFrames;
        }
        startTime = clock();
        }
}



