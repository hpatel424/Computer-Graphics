#ifndef ENEMIES_H
#define ENEMIES_H
#include <GL/gl.h>
#include <time.h>
#include <textureLoader.h>
#include <commons.h>


class enemies
{
    public:
        enemies();
        virtual ~enemies();
        void drawEnemy();
        void drawObject();
        void placeEnemy(vec3);
        void initEnemy(GLuint, int, int);
        void enemyTexture(char*);
        enum acts{IDLE, WALKR, WALKL, ROLLR, ROLLL, JUMP, ATTACK, DIE};
        bool draw, reset;

        void actions();
        acts action;

        int hFrames; //horizontal frames
        int vFrames; //vertical frames

        float xMax, yMax, xMin, yMin;   //for the texture
        vec3 ePos;                      //for the enemy position
        vec2 eSize;
        vec2 eSpeed;
        vec3 eRotation;
        clock_t startTime;

        GLuint tex;
        textureLoader *tLoad = new textureLoader();

        float theta, velocity, t; //t is time on projectiles

    protected:

    private:
};

#endif // ENEMIES_H
