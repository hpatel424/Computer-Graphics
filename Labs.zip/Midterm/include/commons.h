#ifndef COMMONS_H
#define COMMONS_H
#include <math.h>

typedef struct
{
    float x;
    float y;
    float z;
}vec3;

typedef struct
{
    float x;
    float y;
}vec2;

class commons
{
    public:
        commons();
        virtual ~commons();

    protected:

    private:
};

#endif // COMMONS_H
