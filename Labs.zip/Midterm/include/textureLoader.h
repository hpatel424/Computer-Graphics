#ifndef TEXTURELOADER_H
#define TEXTURELOADER_H

#include <SOIL.H>
#include<gl/gl.h>
#include <iostream>
using namespace std;

class textureLoader
{
    public:
        textureLoader();     //constructor
        virtual ~textureLoader();   //destructor
        void loadTexture(char*, GLuint&);   //to load images
        void binder(GLuint);   //to bind image
        unsigned char* image;  //to hold image data
        int width, height;




    protected:

    private:
};

#endif // TEXTURELOADER_H
