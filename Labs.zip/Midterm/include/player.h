#ifndef PLAYER_H
#define PLAYER_H
#include <textureLoader.h>
#include <commons.h>
#include <DeltaTime.h>
#include <Timer.h>

class player
{
    public:
        player();
        virtual ~player();

        vec3 scaleSize;
        vec3 verts[4];

        enum acts{IDLE, WALKR, WALKL, JUMP, ATTACK, DIE};

        float runSpeed;
        float jumpSpeed;

        acts actionTrigger;

        char playerDirection;   // to find out

        void drawPlayer();
        void playerInit(char*, int, int);
        void actions(acts);
        void update();

        int hFrames; //horizontal frames
        int vFrames; //vertical frames

        float xMax, yMax, xMin, yMin;
        vec3 pPos;

        bool jumping;
        float theta, t, velocity;
        clock_t startTime;

        GLuint tex;
        textureLoader *tLoad = new textureLoader();
        bool nextFrame;
    protected:

    private:
};

#endif // PLAYER_H
