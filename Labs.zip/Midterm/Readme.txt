My task is to have the animation run and jump. When you run left or right 
the background should move in the opposite direction from the player. Also, 
there are random objects (I use random size of rectangle) move toward the player 
from right to left side of the screen. Player will jump over objects to avoid 
collision. If there is a collision the objects disappear and spawn back again. 

Instruction
Left/Right key - move left and right 
Spacebar key - to jump