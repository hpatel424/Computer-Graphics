#include "commons.h"

commons::commons()
{
    //ctor
}

commons::~commons()
{
    //dtor
}
