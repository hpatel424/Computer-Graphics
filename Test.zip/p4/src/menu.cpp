#include "menu.h"

menu::menu()
{
    //ctor
}

menu::~menu()
{
    //dtor
}
