#include "player.h"

player::player()
{
    //ctor

    verts[0].x = -0.5; verts[0].y = -0.5; verts[0].z = -1.0;
    verts[1].x = 0.5; verts[1].y = -0.5; verts[1].z = -1.0;
    verts[2].x = 0.5; verts[2].y = 0.5; verts[2].z = -1.0;
    verts[3].x = -0.5; verts[3].y = 0.5; verts[3].z = -1.0;

    position.x = 0.0;
    position.y = -0.5;
    position.z = -2.5;

    actionTrigger = IDLE;
    direction = true;
    playerDir = 'R';
}

player::~player()
{
    //dtor
}
void player::drawPlayer()
{
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,tex);
    glTranslated(position.x,position.y,position.z);
    glBegin(GL_QUADS);

        glTexCoord2f(xMin,yMax);
        glVertex3f(verts[0].x,verts[0].y,verts[0].z);

        glTexCoord2f(xMax,yMax);
        glVertex3f(verts[1].x,verts[1].y,verts[1].z);

        glTexCoord2f(xMax,yMin);
        glVertex3f(verts[2].x,verts[2].y,verts[2].z);

        glTexCoord2f(xMin,yMin);
        glVertex3f(verts[3].x,verts[3].y,verts[3].z);
    glEnd();
    glPopMatrix();
}

void player::playerInit(char* filename, int vFrm, int hFrm)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    vFrames = vFrm;
    hFrames = hFrm;

    xMax = 1.0/(float)hFrames;
    xMin = 0.0;
    yMax = 1.0/(float)vFrames;
    yMin = 0.0;

    tLoad->loadTexture(filename, tex);
}

void player::actions(acts action)
{
    switch(action)
    {
        case IDLE:

            if(playerDir == 'R'){
                xMax = 1.0/(float)hFrames;
                xMin = 0.0;
                yMax = 1.0/(float)vFrames;
                yMin = 0.0;
            }else if(playerDir == 'L')
            {
                xMax = 0.0;
                xMin = 1.0/(float)hFrames;
                yMax = 1.0/(float)vFrames;
                yMin = 0.0;
            }
            actionTrigger = IDLE;
            break;

        case WALKL:
            if(playerDir != 'L'){
                float temp = xMin;
                xMin = xMax;
                xMax = temp;
                playerDir = 'L';

            }
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;
            if(xMax >= 1.0){
                yMin += 1.0/(float)vFrames;
                yMax += 1.0/(float)vFrames;
                xMin--;
                xMax--;
            }
            actionTrigger = WALKL;
        break;
        case WALKR:
            direction = true;
            if(playerDir != 'R'){
                float temp = xMin;
                xMin = xMax;
                xMax = temp;
                playerDir = 'R';
            }
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;
            if(xMax > 1.0){
                yMin += 1.0/(float)vFrames;
                yMax += 1.0/(float)vFrames;
                xMin--;
                xMax--;
            }
            actionTrigger = WALKR;
        break;
    }
}
