#include "Projectiles.h"

//PROJECTILES WILL ONLY ALLOW TEN BULLETS ONSCREEN AT A TIME


Projectiles::Projectiles()
{
    verts[0].x = -0.5; verts[0].y = -0.5; verts[0].z = -1.0;
    verts[1].x = 0.5; verts[1].y = -0.5; verts[1].z = -1.0;
    verts[2].x = 0.5; verts[2].y = 0.5; verts[2].z = -1.0;
    verts[3].x = -0.5; verts[3].y = 0.5; verts[3].z = -1.0;
    velocity = 0.0002;
    //ctor
}

Projectiles::~Projectiles()
{
    //dtor
}

void Projectiles::projectileTexture(char* filename)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    tLoad->loadTexture(filename, tex);
}

void Projectiles::drawProjectile(int i)
{
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D,tex);
    glTranslated(bullets.at(i).Position.x, bullets.at(i).Position.y, bullets.at(i).Position.z);
    glBegin(GL_QUADS);

        glTexCoord2f(0,0);
        glVertex3f(verts[0].x,verts[0].y,verts[0].z);

        glTexCoord2f(1,0);
        glVertex3f(verts[1].x,verts[1].y,verts[1].z);

        glTexCoord2f(1,1);
        glVertex3f(verts[2].x,verts[2].y,verts[2].z);

        glTexCoord2f(0,1);
        glVertex3f(verts[3].x,verts[3].y,verts[3].z);
    glEnd();
    glPopMatrix();
}

void Projectiles::initProjectiles(char* filename)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    tLoad->loadTexture(filename, tex);
}

void Projectiles::addProjectile(vec3 newp) {    //creates a new bullet at the parameter's position (the player)
    if (bulletcount < 10) {    //don't allow more than ten bullets
        //add new bullet
        bullets.push_back(bullet(newp));
        bullets.at(bulletcount).Position.z -= 0.2;        //set the bullet beneath the player level
        cout << "Bullet added" << endl;
        bulletcount++;
    }
}

void Projectiles::advance() {
    for (int i = 0; i < bulletcount; i++) {
            //cout << clock() - bullets.at(i).startTime << endl;
        if (((clock() - bullets.at(i).startTime)/CLOCKS_PER_SEC) > 1) {  //bullets decay after 1 second
            bullets.erase(bullets.begin()+i);   //if a bullet decays, delete it
            cout << "Erased a bullet: " << bulletcount-1 << " left" << endl;
            bulletcount --;
            i--;    //decrement i so it automatically iterates to the same value again but for the reduced vector
        } else {//if a projectile doesn't decay, it advances
                bullets.at(i).Position.y += velocity;
        }
    }
}

