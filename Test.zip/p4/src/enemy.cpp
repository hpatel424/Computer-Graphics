#include "enemy.h"

enemy::enemy()
{
    position.x = 0.7;
    position.y = -0.5;
    position.z = -2.5;

    eSize.x = 0.3;
    eSize.y = 0.0;

    eRotation.x = eRotation.y = eRotation.z = 0;
    eSpeed.x = 0.005;
    eSpeed.y = 0.0;

    startTime = clock();
    action = WALKL;

    theta = 30*PI/180;
    velocity = 35;
    t = 0;
}

enemy::~enemy()
{
    //dtor
}

void enemy::drawEnemy()
{
    glBindTexture(GL_TEXTURE_2D,tex);
    glPushMatrix();
        glTranslatef(position.x, position.y,position.z);
        glRotatef(eRotation.x, 1.0, 0.0, 0.0); glRotatef(eRotation.y, 0.0, 1.0, 0.0); glRotatef(eRotation.z, 0.0, 0.0, 1.0);
        glScalef(eSize.x, eSize.y, 1.0);

        glBegin(GL_POLYGON);
            glTexCoord2f(xMin, yMin);
            glVertex3f(1.0,1.0,0.0);

            glTexCoord2f(xMax, yMin);
            glVertex3f(-1.0,1.0,0.0);

            glTexCoord2f(xMax, yMax);
            glVertex3f(-1.0,-1.0,0.0);

            glTexCoord2f(xMin, yMax);
            glVertex3f(1.0,-1.0,0.0);

        glEnd();
    glPopMatrix();
}

void enemy::placeEnemy(vec3 p)
{
    position.x = p.x;
    position.y = p.y;
    position.z = p.z;
}

void enemy::enemyTexture(char* filename)
{
    tLoad->loadTexture(filename, tex);

}


void enemy::initEnemy(GLuint tex, int vFrm, int hFrm)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    vFrames = vFrm;
    hFrames = hFrm;

    xMax = 1.0/(float)hFrames;
    xMin = 0.0;
    yMax = 1.0/(float)vFrames;
    yMin = 0.0;

    this->tex = tex;
}

void enemy::actions()
{
    switch(action)
    {
    case IDLE:
        if(clock()-startTime>30){
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;
            startTime = clock();
        }
    break;

    case WALKL:
        if(clock()-startTime>60){
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;

            position.x -=eSpeed.x;
            position.y = -0.5;
            yMax = 1.0/(float)vFrames;
            yMin = 0.0;
            eRotation.z = 0.0;
            startTime = clock();
        }
    break;
    case WALKR:
        if(clock()-startTime>60){
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;

            position.x +=eSpeed.x;
            position.y = -0.5;
            yMax = 1.0;
            yMin = 1.0/(float)vFrames;
            eRotation.z = 0.0;
            startTime = clock();
        }
    break;
    case ROLLR:
        if(clock()-startTime>60){
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;

            //position.x +=eSpeed.x;
            yMax = 1.0;
            yMin = 1.0/(float)vFrames;

            eRotation.z += (float(rand())/float(RAND_MAX))*50.0;
            position.x += 0.007;
            startTime = clock();
        }
    break;
    case ROLLL:
        if(clock()-startTime>60){
            xMin +=1.0/(float)hFrames;
            xMax +=1.0/(float)hFrames;

            //position.x +=eSpeed.x;
            yMax = 1.0;
            yMin = 1.0/(float)vFrames;

            eRotation.z += (float(rand())/float(RAND_MAX))*100.0;
            position.x -= velocity*t*cos(theta)/1200;
            position.y += (velocity*t*sin(theta)-0.5*GRAVITY*t*t)/700;

            if(position.y>=-0.5){
                t+=0.2;
            }else{
                t=0;
                position.y=-0.5;
            }

            startTime = clock();
        }
    break;
    }

}
