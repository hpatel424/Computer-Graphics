#ifndef PROJECTILES_H
#define PROJECTILES_H

#include <GL/gl.h>
#include<textureloader.h>

#include <commons.h>
#include <vector>
using namespace std;



    class bullet {
        public:
        vec3 Position;
        clock_t startTime;
        bullet(vec3 v) {
            Position = v;
            startTime = clock();
        };
    };


class Projectiles
{
    public:
        Projectiles();
        virtual ~Projectiles();
        vector<bullet> bullets;
        int bulletcount;
        float velocity;

        void addProjectile(vec3);
        //void addProjectile(float, float, float);
        void projectileTexture(char*);
        void drawProjectile(int);
        void initProjectiles(char*);
        void advance();

        vec3 verts[4];
        GLuint tex;
        textureLoader *tLoad = new textureLoader();
    protected:

    private:
};

#endif // PROJECTILES_H
