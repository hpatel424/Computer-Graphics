#ifndef BULLET_H
#define BULLET_H
#include <commons.h>
typedef struct bullet {
    vec3 Position;
    clock_t startTime;
    bullet(float, float, float);
    bullet(vec3);
} ;

    bullet::bullet (vec3 v) {
        Position = v;
        startTime = clock();
    }

    bullet::bullet (float x, float y, float z) {
        Position.x = x;
        Position.y = y;
        Position.z = z;
        startTime = clock();
    }
#endif //BULLET_H
