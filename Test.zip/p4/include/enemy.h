#ifndef ENEMY_H
#define ENEMY_H

#include <GL/gl.h>
#include<textureloader.h>

#include <commons.h>
#include <time.h>

class enemy
{
    public:
        enemy();
        virtual ~enemy();
        void drawEnemy();
        void placeEnemy(vec3);
        void initEnemy(GLuint, int, int);
        void enemyTexture(char*);

        enum acts{IDLE, WALKL, WALKR, ROLLR, ROLLL, JUMP, ATTACK, DIE};
        void actions();
        acts action;





        int hFrames;
        int vFrames;

        float xMax, yMax, xMin, yMin;
        vec3 position;
        vec2 eSize;
        vec2 eSpeed;    //movement speed

        vec3 eRotation;      //rotation

        clock_t startTime;

        GLuint tex;
        textureLoader *tLoad = new textureLoader();

        float theta, velocity, t;//t is projectile time


        char direction; //determine direction including up and down


    protected:

    private:
};

#endif // ENEMY_H
