#ifndef PLAYER_H
#define PLAYER_H

#include <GL/gl.h>
#include<textureloader.h>

#include <commons.h>


class player
{
    public:
        player();
        virtual ~player();

        vec3 scaleSize;
        vec3 verts[4];

        enum acts{IDLE, WALKL, WALKR, JUMP, ATTACK, DIE};
        acts actionTrigger;

        float runSpeed;

        void drawPlayer();
        void playerInit(char*, int, int);
        void actions(acts);



        int hFrames;
        int vFrames;

        float xMax, yMax, xMin, yMin;
        vec3 position;

        GLuint tex;
        textureLoader *tLoad = new textureLoader();

        bool direction;
        char playerDir; //determine direction including up and down

    protected:

    private:
};

#endif // PLAYER_H
