#ifndef MENU_H
#define MENU_H


class menu
{
    public:
        menu();
        virtual ~menu();

    protected:

    private:
};

#endif // MENU_H
