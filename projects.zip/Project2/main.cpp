

// Harry Patel
// CSCI 173 - Graphics
//Project 2 - Sphere Move

#include <string.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <iostream>

#include <math.h>
#include <time.h>

#define radius 1.3 //Radius of sphere as per the assignment
using namespace std;

clock_t startTime;  // variable to store the start time

bool WireFrame= false;

const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

GLfloat Wwidth, Wheight;
GLfloat cameraAngle = 0, cameraZoom = 0; // To rotate left and right and to zoom in and out.
GLfloat t = 0.04; // t variable to store the spheres speed.
GLfloat bound = 4.0; // variable to set bounds for collision.
GLfloat q = bound - 0.1; // variable to set bounds for collision.
GLfloat spin = 0.0; // spin variable.
GLfloat x, y, z; // Variables to store the position of the spheres.
GLfloat xpos = 0, ypos = 0, zpos = 0; // x, y, z positions of the spheres.
GLfloat dx = 1, dy = 1, dz = 1; // Variables to  hold the direction of the sphere traveling.
GLfloat speedX, speedY, speedZ; // Variables to hold the speed of the sphere traveling in each direction.
GLfloat sphereX = 0.0, sphereY = 0.0, sphereZ = 0.0; //Variables to check for collision for each sphere.
GLfloat color[3]; // Array which changes color of the sphere after collision.

/* GLUT callback Handlers */
static void resize(int width, int height)
{
    double Ratio;
    Wwidth = (float)width;
    Wheight = (float)height;
    Ratio= (double)width /(double)height;

    glViewport(0,0,(GLsizei) width,(GLsizei) height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective (50.0f, Ratio, 0.1f, 100.0f);
}

// Collision
int collision(float xpos, float ypos, float zpos)
{
    //Using distance formula it calculates the distance and stores in the distance variable.
    float distance = sqrt((xpos - sphereX) * (xpos - sphereX) + (ypos - sphereY) * (ypos - sphereY) + (zpos - sphereZ) * (zpos - sphereZ));

    if (distance <= radius + 0.5) // Condition to check for sphere collision.
    {
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;

        //After collision, calculates the new direction of travel of the sphere.
        float nx = (xpos - sphereX) / distance;
        float ny = (ypos - sphereY) / distance;
        float nz = (zpos - sphereZ) / distance;
        float n_length = sqrt(nx * nx + ny * ny + nz * nz);
        nx /= n_length;
        ny /= n_length;
        nz /= n_length;

        //Reflects the direction vector about the normal to the sphere's surface.
        float dot = dx * nx + dy * ny + dz * nz;
        dx = dx - 2 * dot * nx;
        dy = dy - 2 * dot * ny;
        dz = dz - 2 * dot * nz;

        //Moves the ball back along its direction vector until it's just touching the sphere's surface.
        xpos = sphereX + radius * nx;
        ypos = sphereY + radius * ny;
        zpos = sphereZ + radius * nz;
    }

    if (xpos >= bound) //Condition to check if it hits the right-sided wall.
    {
        //Assigns new color to sphere.
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;
        dx = -dx;
        xpos = bound - radius;
        return 1;
    }

    if (xpos <= -bound) //Condition to check if it hits the left-sided wall.
    {
        //Assigns new color to sphere.
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;
        dx = -dx;
        xpos = -bound + radius;
        return 2;
    }

    if (ypos >= bound) //Condition to check if it hits the ceiling.
    {
        //Assigns new color to sphere.
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;
        dy = -dy;
        ypos = bound - radius;
        return 3;
    }

    if (ypos <= -bound) //Condition to check if it hits the floor.
    {
        //Assigns new color to sphere.
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;
        dy = -dy;
        ypos = -bound + radius;
        return 4;
    }

    if (zpos >= bound) //Condition to check if it hits the front wall.
    {
        //Assigns new color to sphere.
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;
        dz = -dz;
        zpos = bound - radius;
        return 5;
    }

    if (zpos <= -bound) //Condition to check if it hits the back wall.
    {
        //Assigns new color to sphere.
        color[0] = (float)rand() / RAND_MAX;
        color[1] = (float)rand() / RAND_MAX;
        color[2] = (float)rand() / RAND_MAX;
        dz = -dz;
        zpos = -bound + radius;
        return 6;
    }
    return 0;
}

// Timer Function
static void timer(int value)
{

    float dirX = (float) (rand()) / (float) (RAND_MAX/q);
    float dirY = (float) (rand()) / (float) (RAND_MAX/q);
    float dirZ = (float) (rand()) / (float) (RAND_MAX/q);

    //The conditions check and it depends on the return value from the collision function.
    if(collision(x,y,z) == 1)
    {
        dx = -dirX;
    }
    else if(collision(x,y,z) == 2)
    {
        dx = dirX;
    }
    else if(collision(x,y,z) == 3)
    {
        dy = -dirY;
    }
    else if(collision(x,y,z) == 4)
    {
        dy = dirY;
    }
    else if(collision(x,y,z) == 5)
    {
        dz = -dirZ;
    }
    else if(collision(x,y,z) == 6)
    {
        dz = dirZ;
    }

    glutPostRedisplay();
}

static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(0, 2, 20, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    if(WireFrame)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);      //Draw Our Mesh In Wire-frame Mesh
    else
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);      //Toggle WIRE FRAME

    //your code here
    glTranslated(0, 0, cameraZoom); //To zoom in, and zoom out
    glRotatef(cameraAngle, 0.0, 5.0, 0.0);

    //Sphere Generation
    //Sphere 1
    glPushMatrix();
    glTranslated(x,y,z); //Sphere moves along this same axis.
    glColor3f(color[0], color[1], color[2]); //Color is randomly assign after collision.
    glutSolidSphere(radius,22,22);
    glPopMatrix();

    //Sphere 2
    glPushMatrix();
    glTranslated(-x,y,z); //Sphere moves along this same axis.
    glColor3f(color[0], color[1], color[2]); //Color is randomly assign after collision.
    glutSolidSphere(radius,22,22);
    glPopMatrix();

    //Sphere 3
    glPushMatrix();
    glTranslated(x,-y,z); //Sphere moves along this same axis.
    glColor3f(color[0], color[1], color[2]); //Color is randomly assign after collision.
    glutSolidSphere(radius,22,22);
    glPopMatrix();

    //Sphere 4
    glPushMatrix();
    glTranslated(-x,y,-z); //Sphere moves along this same axis.
    glColor3f(color[0], color[1], color[2]); //Color is randomly assign after collision.
    glutSolidSphere(radius,22,22);
    glPopMatrix();

    // Wire-frame Cube
    glPushMatrix();
    glColor3f(0.0, 0.0, 1.0); //Color of the wire-frame blue.
    glutWireCube(12); //Size of the wire-frame cube.
    glPopMatrix();

    glutTimerFunc(500,timer,0);

    glutSwapBuffers();
}

static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27 :
    case 'q':
        exit(0);
        break;
    }
}

void Specialkeys(int key, int x, int y)
{
    switch(key)
    {
    case GLUT_KEY_LEFT : //Rotate camera left
        cameraAngle += 10.0;
        break;

    case GLUT_KEY_RIGHT : //Rotate camera right
        cameraAngle -= 10.0;
        break;

    case GLUT_KEY_UP : //Zoom in with camera
        cameraZoom += 0.5;
        break;

    case GLUT_KEY_DOWN : //Zoom out with camera
        cameraZoom -= 0.5;
        break;
    }
    glutPostRedisplay();
}

static void idle(void)
{
    if(clock() - startTime > 25) // Slows down the sphere's movement in the cube.
    {
        spin += 0.5;
        speedX = t * (dx); //Speed of the sphere is multiplied by the traveling x-direction.
        x = x +  speedX; //Adds the speed to current x position.

        speedY = t * (dy); //Speed of the sphere is multiplied by the traveling y-direction.
        y = y + speedY; //Adds the speed to current y position.

        speedZ = t * (dz); //Speed of the sphere is multiplied by the traveling z-direction.
        z = z + speedZ; //Adds the speed to current z position.

        startTime = clock(); //resets the start time variable.
    }

    glutPostRedisplay();
}

static void init(void)
{

    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);

    glEnable(GL_DEPTH_TEST);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glShadeModel(GL_SMOOTH);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);
}

/* Program entry point */
int main(int argc, char *argv[])
{
    glutInit(&argc, argv);

    glutInitWindowSize(1200,1000);
    glutInitWindowPosition(0,0);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("Project 2 - Moving Spheres");
    init();
    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutKeyboardFunc(key);
    glutSpecialFunc(Specialkeys);
    glutIdleFunc(idle);
    glutMainLoop();

    return EXIT_SUCCESS;
}
