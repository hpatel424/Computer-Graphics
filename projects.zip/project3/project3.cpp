
//Harry Patel
//CSCI 173: Computer Graphics
//Project 3: Model Loader with VBO

#include <string.h>
#define GLEW_STATIC
#include <GL/glew.h>
#include <GL/gl.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <SOIL.h>
#define PI 3.14159

using namespace std;

bool WireFrame= false;
float i = 0;

const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

float xpos =0;
float ypos =0;
float cameraZoom = 0;
float Wwidth,Wheight;


// 3 different Models to load
int ven, ele, cow ;

static GLint RotateX=0; //Rotation of model X index.
static GLint RotateY=0; // Rotation of Model Y index.
static GLint RotateZ=0; // Rotation of Model Z index.

//Quaternion Rotations
GLfloat matrixX[16];
GLfloat matrixY[16];
GLfloat matrixZ[16];
GLfloat x, y, z, w;

//Glut callback handlers.

//Array for normals.
GLfloat normals[] = {

     0, 0, 1,   0, 0, 1,   0, 0, 1,   0, 0, 1,  // Front side v0,v1,v2,v3
     1, 0, 0,   1, 0, 0,   1, 0, 0,   1, 0, 0,  // Right side v0,v3,v4,v5
     0, 1, 0,   0, 1, 0,   0, 1, 0,   0, 1, 0,  // Top v0,v5,v6,v1
    -1, 0, 0,  -1, 0, 0,  -1, 0, 0,  -1, 0, 0,  // Left side v1,v6,v7,v2
     0,-1, 0,   0,-1, 0,   0,-1, 0,   0,-1, 0,  // Bottom v7,v4,v3,v2
     0, 0,-1,   0, 0,-1,   0, 0,-1,   0, 0,-1   // Back side v4,v7,v6,v5
};

//Array for Texture coordinates.
GLfloat texCoords[] = {
    1, 0,   0, 0,   0, 1,   1, 1,               // Front side v0,v1,v2,v3
    0, 0,   0, 1,   1, 1,   1, 0,               // Right side v0,v3,v4,v5
    1, 1,   1, 0,   0, 0,   0, 1,               // Top v0,v5,v6,v1
    1, 0,   0, 0,   0, 1,   1, 1,               // Left side v1,v6,v7,v2
    0, 1,   1, 1,   1, 0,   0, 0,               // Bottom v7,v4,v3,v2
    0, 1,   1, 1,   1, 0,   0, 0                // Back side v4,v7,v6,v5
};

//Array for Colors.
GLfloat colors[] = {

     1, 1, 1,   1, 1, 0,   1, 0, 0,   1, 0, 1,  // Front side v0,v1,v2,v3
     1, 1, 1,   1, 0, 1,   0, 0, 1,   0, 1, 1,  // Right side v0,v3,v4,v5
     1, 1, 1,   0, 1, 1,   0, 1, 0,   1, 1, 0,  // Top v0,v5,v6,v1
     1, 1, 0,   0, 1, 0,   0, 0, 0,   1, 0, 0,  // Left side v1,v6,v7,v2
     0, 0, 0,   0, 0, 1,   1, 0, 1,   1, 0, 0,  // Bottom v7,v4,v3,v2
     0, 0, 1,   0, 0, 0,   0, 1, 0,   0, 1, 1   // Back side v4,v7,v6,v5
};

// Vertex position array for the objects.
GLfloat vertices[]  = {
     .5f, .5f, .5f,  -.5f, .5f, .5f,  -.5f,-.5f, .5f,  .5f,-.5f, .5f, // Front side v0,v1,v2,v3
     .5f, .5f, .5f,   .5f,-.5f, .5f,   .5f,-.5f,-.5f,  .5f, .5f,-.5f, // Right side v0,v3,v4,v5
     .5f, .5f, .5f,   .5f, .5f,-.5f,  -.5f, .5f,-.5f, -.5f, .5f, .5f, // Top v0,v5,v6,v1
    -.5f, .5f, .5f,  -.5f, .5f,-.5f,  -.5f,-.5f,-.5f, -.5f,-.5f, .5f, // Left side v1,v6,v7,v2
    -.5f,-.5f,-.5f,   .5f,-.5f,-.5f,   .5f,-.5f, .5f, -.5f,-.5f, .5f, // Bottom v7,v4,v3,v2
     .5f,-.5f,-.5f,  -.5f,-.5f,-.5f,  -.5f, .5f,-.5f,  .5f, .5f,-.5f  // Back side v4,v7,v6,v5
};

// glDrawElements() index array
// A model(cube)requires 36 index.

GLuint indices[] = {
     0, 1, 2,   2, 3, 0,    // Front side v0-v1-v2, v2-v3-v0
     4, 5, 6,   6, 7, 4,    // Right side v0-v3-v4, v4-v5-v0
     8, 9,10,  10,11, 8,    // Top v0-v5-v6, v6-v1-v0
    12,13,14,  14,15,12,    // Left side v1-v6-v7, v7-v2-v1
    16,17,18,  18,19,16,    // Bottom v7-v4-v3, v3-v2-v7
    20,21,22,  22,23,20     // Back side v4-v7-v6, v6-v5-v4
};

// VBO and IBO handlers for Vertexes and Indexes respectively.
GLuint vboID, iboID;

// Array float
// Int values for index
// Function to create VBO
void createVBO()
{
    // Buffers generating
    glGenBuffers(1, &vboID);
    glGenBuffers(1, &iboID);

    size_t nSize = sizeof(normals);     // Size of Normals
    size_t cSize = sizeof(colors);      // Size of Colors
    size_t tSize = sizeof(texCoords);   // Size of Tex Coordinates
    size_t vSize = sizeof(vertices);    // Size of Vertex

    // Binding Buffers
    glBindBuffer(GL_ARRAY_BUFFER, vboID);   // Buffer for Vertex
    glBufferData(GL_ARRAY_BUFFER, (vSize + nSize + cSize + tSize), 0, GL_STATIC_DRAW);    // Allocating Buffer Space.
    glBufferSubData(GL_ARRAY_BUFFER, 0, vSize, vertices);       // Loading the data to the buffers.
    glBufferSubData(GL_ARRAY_BUFFER, vSize, nSize, normals);    // Loading normal data to the buffers.
    glBufferSubData(GL_ARRAY_BUFFER, vSize + nSize, cSize, colors);     // Loading color data to the buffers.
    glBufferSubData(GL_ARRAY_BUFFER, vSize + nSize + cSize, tSize, texCoords);      // Loading the texture coordinates to buffers.

    glBindBuffer(GL_ARRAY_BUFFER, 0); // Unbind Buffer, Releasing
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboID);   // Index Buffer
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

// Draw VBO function
void drawVBO()
{

    glBindBuffer(GL_ARRAY_BUFFER, vboID);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboID);

    glEnableClientState(GL_VERTEX_ARRAY);   // Enables and Creates a pointer
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glVertexPointer(3, GL_FLOAT, 0, (void*)0);  // Vertex Pointer
    glNormalPointer(GL_FLOAT, 0, (void*)sizeof(vertices));  // Normal Pointer
    glColorPointer(3, GL_FLOAT, 0, (void*)sizeof(vertices) + sizeof(normals));  // Color Pointer
    glTexCoordPointer(2, GL_FLOAT, 0, (void*)sizeof(vertices) + sizeof(normals) + sizeof(colors)); // Texture Coordinates Pointer

    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, (void*)0);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

// Creates a from Axis angle
void createFromAxisAngle(GLfloat X, GLfloat Y, GLfloat Z, GLfloat degree){

GLfloat angle = (GLfloat)((degree / 180.0f) * PI); // Degree to radians angles conversion.

GLfloat result = (GLfloat)sin(angle / 2.0f); // Calculating sin(theta/2)

w = (GLfloat)cos( angle / 2.0f ); // Calculating w through cos(theta/2)

//Calculating x, y, z of quaternions
x = (GLfloat)(X * result);
y = (GLfloat)(Y * result);
z = (GLfloat)(Z * result);

}

// Create Matrix Function
void createMatrix(GLfloat *pMatrix){

    // Projection matrix 1st row
    pMatrix[0] = 1.0f - 2.0f * ( y * y + z * z );
    pMatrix[1] = 2.0f * (x * y + z * w);
    pMatrix[2] = 2.0f * (x * z - y * w);
    pMatrix[3] = 0.0f;

    // Projection matrix 2nd row
    pMatrix[4] = 2.0f * ( x * y - z * w );
    pMatrix[5] = 1.0f - 2.0f * ( x * x + z * z );
    pMatrix[6] = 2.0f * (z * y + x * w );
    pMatrix[7] = 0.0f;

    // Projection matrix 3rd row
    pMatrix[8] = 2.0f * ( x * z + y * w );
    pMatrix[9] = 2.0f * ( y * z - x * w );
    pMatrix[10] = 1.0f - 2.0f * ( x * x + y * y );
    pMatrix[11] = 0.0f;

    // Projection matrix 4th row
    pMatrix[12] = 0.0f;
    pMatrix[13] = 0.0f;
    pMatrix[14] = 0.0f;
    pMatrix[15] = 1.0f;

}

static void resize(int width, int height)
{
    double Ratio;
    Wwidth = (float)width;
    Wheight = (float)height;
    Ratio= (double)width /(double)height;
    glViewport(0,0,(GLsizei) width,(GLsizei) height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective (45.0f,Ratio,0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0,0,10,0.0,0.0,0.0,0.0,1.0,0.0);
    if(WireFrame)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Draw Our Mesh In Wire-frame Mesh
    else
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); //Toggle WIRE FRAME

    // your code here
    glTranslated(0,0,cameraZoom); // To zoom in and out using END and HOME respectively

    //-- Quaternion Rotations for X, Y, Z --
    createMatrix(matrixX); //Quaternion for X
    createFromAxisAngle(1, 0, 0, RotateX);
    glMultMatrixf(matrixX);

    createMatrix(matrixY); //Quaternion for Y
    createFromAxisAngle(0, 1, 0, RotateY);
    glMultMatrixf(matrixY);

    createMatrix(matrixZ); //Quaternion for Z
    createFromAxisAngle(0, 0, 1, RotateZ);
    glMultMatrixf(matrixZ);


    //-- VBO Model Implementations --
    glPushMatrix();
        glScalef(3.0, 3.0, 3.0);
        drawVBO();
    glPopMatrix();

    glutSwapBuffers();
}

static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 27 :
        case 'q':
            exit(0);
            break;
        case 'w':
            WireFrame =!WireFrame;
            break;

        //-- Model 1 --
        case '1':
            glCallList(cow);
            break;

        //-- Model 2 --
            glCallList(ele);
        case '2':
            break;

        //-- Model 3 --
        case '3':
            glCallList(ven);
            break;
    }
}

void Specialkeys(int key, int x, int y)
{
    switch(key)
    {
        case GLUT_KEY_UP:
            RotateX = (RotateX + 5)%360;
            break;
        case GLUT_KEY_DOWN:
            RotateX = (RotateX - 5)%360;
            break;
        case GLUT_KEY_LEFT:
            RotateY = (RotateY + 5) % 360;
            break;
        case GLUT_KEY_RIGHT:
            RotateY = (RotateY - 5) % 360;
            break;
        case GLUT_KEY_END:
            cameraZoom += 1.0;
            break;
        case GLUT_KEY_HOME:
            cameraZoom -= 1.0;
            break;
    }
    glutPostRedisplay();
}

static void idle(void)
{
    // Use parametric equation with t increment for x-position and y-posistion
    // Don't need a loop
    glutPostRedisplay();
}

void mouse(int btn, int state, int x, int y){
    float scale = 100*(Wwidth/Wheight);
    switch(btn)
    {
        case GLUT_LEFT_BUTTON:
            if(state==GLUT_DOWN)
            {
               // get new mouse coordinates for x,y
               // use scale to match right
            }
            break;
    }
     glutPostRedisplay();
};

static void init(void)
{

    glewInit();

    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_DEPTH_TEST);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glShadeModel(GL_SMOOTH);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);

    createVBO();
}

/* Program entry point */
int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitWindowSize(800,800);
    glutInitWindowPosition(400,200);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("Project 3: Model Loader with VBO");
    init();
    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutKeyboardFunc(key);
    glutSpecialFunc(Specialkeys);
    glutIdleFunc(idle);
    glutMainLoop();
    return EXIT_SUCCESS;
}
