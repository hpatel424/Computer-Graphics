
//Harry Patel
//Computer Graphics-173
//Assignment-4: 2D animation


#define GLEW_STATIC
#include <GL/glew.h>
#include <string.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <fstream>
#include<SOIL.h>
#include <time.h>

#define PI 3.14159

using namespace std;

bool WireFrame= false;
float i =0;
const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

    float position[] = { 2.0, 0.0, 0.0, 1.0 };

    float xpos =0;
    float ypos =0;
    float Wwidth,Wheight;

    float thetaX=0;
    float thetaY=0;
    float thetaZ=0;

    float spin =0.0;
    float anim =2.0;
    int factor =1;
    GLint loc;
    GLint locTheta;

    float xMin,xMax,yMin,yMax;
    float xMin2, xMax2, yMin2, yMax2;
    float xMinP, xMaxP, yMinP, yMaxP;
    float xMinC, xMaxC, yMinC, yMaxC;
    float frames,frames2;

    bool dirA = false;
    bool dirA2 = false;
    float pT = 0.0;


typedef struct{
float x;
float y;
float z;

}vec3;

    vec3 clicks[3] = {0};
    int cnt = 0;

    float t; //mouseX mouseY t for iteration
    float t1 = 0;

    float s = 0.0;

    //float xpos =0;
    float yposb =0;
    float zposb =0;

    //float ballX = 0;
    float ballY = 0;
    float ballZ = 0;
    float startAt = 0;

    //bool isHiding = false;

    clock_t startTime;

    unsigned vs,fs,gs,program,program1;
/* GLUT callback Handlers */

GLuint tex[20];

void loadShaderFiles(char *fileName, string &str)
{
    char tmp[1024];
    ifstream in(fileName);

    if(!in.is_open()){ cout<< "File cannot open "<<endl;
    return;
    }

    while(!in.eof()){

        in.getline(tmp,1024);
        str += tmp;
        str +='\n';
    }

    cout<<fileName<<endl;
}

unsigned int compileShader(string &source, unsigned int mode)
{
    unsigned int id;

    const char* csource;
    char error[1024];

    id = glCreateShader(mode);
    csource =source.c_str();

    glShaderSource(id,1,&csource,NULL);
    glCompileShader(id);

    glGetShaderInfoLog(id,1024,NULL,error);   // to catch errors

    cout<< "compile status \n"<<error<<endl;

    return id;

}

void initShader(char *vertexFile, char *fragFile,char *geoFile, unsigned &prog)
{
    string source;

    loadShaderFiles(vertexFile,source);

    vs= compileShader(source,GL_VERTEX_SHADER);

    source ="";

    loadShaderFiles(fragFile,source);

    fs = compileShader(source,GL_FRAGMENT_SHADER);

     source ="";

    loadShaderFiles(geoFile,source);

    gs = compileShader(source,GL_GEOMETRY_SHADER);

    prog = glCreateProgram();

    glAttachShader(prog,vs);
    glAttachShader(prog,fs);
    glAttachShader(prog,gs);

    glLinkProgram(prog);

    glDetachShader(prog,vs);
    glDetachShader(prog,fs);
    glDetachShader(prog,gs);
}

void clean(){

 glDeleteShader(vs);
 glDeleteShader(fs);
 glDeleteShader(gs);
 glDeleteShader(program);
 glDeleteShader(program1);
}


void TLoad(char *file, GLuint tex){

     int width, height; // width & height for the image reader
     unsigned char* image;

     glBindTexture(GL_TEXTURE_2D, tex); // images are 2D arrays of pixels, bound to the GL_TEXTURE_2D target.

     image = SOIL_load_image(file, &width, &height, 0, SOIL_LOAD_RGBA);
     glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

     if(!image) cout<< "file not found "<< file  <<endl;
    // binding image data
     SOIL_free_image_data(image);

	 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_NEAREST);
}

void wall()//used to create the animated 2d character
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D,tex[4]);
    glScalef(2.0 ,2.0 ,2.0);
    glTranslatef(0.0, -2.0, -3.0);
    //glEnable(GL_SCISSOR_TEST);
    glBegin(GL_QUADS);
    glNormal3f(0.0f, 0.0f, 1.0f);
    glTexCoord2f(xMaxP/frames, yMinP); glVertex3f(-1.0f,  1.0f, -1.0f);
    glTexCoord2f(xMaxP/frames, yMaxP); glVertex3f(-1.0f, -1.0f, -1.0f);
    glTexCoord2f(xMinP/frames, yMaxP); glVertex3f( 1.0f, -1.0f, -1.0f);
    glTexCoord2f(xMinP/frames, yMinP); glVertex3f( 1.0f,  1.0f, -1.0f);
    glEnd();
    glEnable(GL_LIGHTING);
}

void wall2()
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D,tex[4]);
    glScalef(0.5, 0.5, 0.5);
    glTranslatef(2.0, 0.0, 0.0);
    glRotatef(180, 0.0, 1.0, 0.0);
    //glEnable(GL_SCISSOR_TEST);
    glBegin(GL_QUADS);
    glNormal3f(0.0f, 0.0f, 1.0f);
    glTexCoord2f(xMaxC/frames2, yMinC); glVertex3f(-1.0f,  1.0f, -1.0f);
    glTexCoord2f(xMaxC/frames2, yMaxC); glVertex3f(-1.0f, -1.0f, -1.0f);
    glTexCoord2f(xMinC/frames2, yMaxC); glVertex3f( 1.0f, -1.0f, -1.0f);
    glTexCoord2f(xMinC/frames2, yMinC); glVertex3f( 1.0f,  1.0f, -1.0f);
    glEnd();
}

void skyBox() // changed skybox so that it was able to move the background. although didnt do a skydome
{
    glDisable(GL_LIGHTING);
    glTranslatef(0.0,0.0,-10.0);
    glRotated(thetaX,1,0,0);
    glRotated(thetaY,0,1,0);
    glRotated(thetaZ,0,0,1);
    glScalef(25.0,7.0,20.0);

    glEnable(GL_TEXTURE_2D);
  //glEnable(GL_SCISSOR_TEST);
glBindTexture(GL_TEXTURE_2D,tex[9]);
glBegin(GL_QUADS);
      // Front Face  Y
    glNormal3f(0.0f, 0.0f, -1.0f);
    glTexCoord2f(xMin2, yMin2); glVertex3f(-1.0f,  1.0f,  1.0f);  // Bottom Left Of The Texture and Quad
    glTexCoord2f(xMax2, yMin2); glVertex3f( 1.0f,  1.0f,  1.0f);  // Bottom Right Of The Texture and Quad
    glTexCoord2f(xMax2, yMax2); glVertex3f( 1.0f, -1.0f,  1.0f);  // Top Right Of The Texture and Quad
    glTexCoord2f(xMin2, yMax2); glVertex3f(-1.0f, -1.0f,  1.0f);  // Top Left Of The Texture and Quad
glEnd();


    // Right face  Y
glBindTexture(GL_TEXTURE_2D,tex[12]);
glBegin(GL_QUADS);
    glNormal3f(-1.0f, 0.0f, 0.0f);
    glTexCoord2f(1, 0); glVertex3f( 1.0f,  1.0f, -1.0f);  // Bottom Right Of The Texture and Quad
    glTexCoord2f(1, 1); glVertex3f( 1.0f, -1.0f, -1.0f);  // Top Right Of The Texture and Quad
    glTexCoord2f(0, 1); glVertex3f( 1.0f, -1.0f,  1.0f);  // Top Left Of The Texture and Quad
    glTexCoord2f(0, 0); glVertex3f( 1.0f,  1.0f,  1.0f);  // Bottom Left Of The Texture and Quad
glEnd();


     // Left Face  Y
glBindTexture(GL_TEXTURE_2D,tex[10]);
glBegin(GL_QUADS);
    glNormal3f(1.0f, 0.0f, 0.0f);
    glTexCoord2f(0, 0); glVertex3f(-1.0f,  1.0f, -1.0f);  // Bottom Left Of The Texture and Quad
    glTexCoord2f(1, 0); glVertex3f(-1.0f,  1.0f,  1.0f);  // Bottom Right Of The Texture and Quad
    glTexCoord2f(1, 1); glVertex3f(-1.0f, -1.0f,  1.0f);  // Top Right Of The Texture and Quad
    glTexCoord2f(0, 1); glVertex3f(-1.0f, -1.0f, -1.0f);  // Top Left Of The Texture and Quad
glEnd();

  glBindTexture(GL_TEXTURE_2D,tex[8]);
    glBegin(GL_QUADS);
   // Top Face Z
    glNormal3f(0.0f, -1.0f, 0.0f);
    glTexCoord2f(xMin, yMax); glVertex3f( 1.0f,  1.0f, -1.0f);  // Top Left Of The Texture and Quad
    glTexCoord2f(xMin, yMin); glVertex3f( 1.0f,  1.0f,  1.0f);  // Bottom Left Of The Texture and Quad
    glTexCoord2f(xMax, yMin); glVertex3f(-1.0f,  1.0f,  1.0f);  // Bottom Right Of The Texture and Quad
    glTexCoord2f(xMax, yMax); glVertex3f(-1.0f,  1.0f, -1.0f);  // Top Right Of The Texture and Quad
 glEnd();

  glBindTexture(GL_TEXTURE_2D,tex[11]);
    glBegin(GL_QUADS);
    // Bottom Face  Z
    glNormal3f(0.0f, 1.0f, 0.0f);
    glTexCoord2f(xMax, yMax); glVertex3f( -1.0f, -1.0f,  1.0f);  // Top Right Of The Texture and Quad
    glTexCoord2f(xMin, yMax); glVertex3f(  1.0f, -1.0f,  1.0f);  // Top Left Of The Texture and Quad
    glTexCoord2f(xMin, yMin); glVertex3f(  1.0f, -1.0f, -1.0f);  // Bottom Left Of The Texture and Quad
    glTexCoord2f(xMax, yMin); glVertex3f( -1.0f, -1.0f, -1.0f);  // Bottom Right Of The Texture and Quad
glEnd();

glBindTexture(GL_TEXTURE_2D,tex[13]);
    glBegin(GL_QUADS);
  // Back Face Y
    glNormal3f(0.0f, 0.0f, 1.0f);
    glTexCoord2f(xMax, yMin); glVertex3f(-1.0f,  1.0f, -1.0f);  // Bottom Right Of The Texture and Quad
    glTexCoord2f(xMax, yMax); glVertex3f(-1.0f, -1.0f, -1.0f);  // Top Right Of The Texture and Quad
    glTexCoord2f(xMin, yMax); glVertex3f( 1.0f, -1.0f, -1.0f);  // Top Left Of The Texture and Quad
    glTexCoord2f(xMin, yMin); glVertex3f( 1.0f,  1.0f, -1.0f);  // Bottom Left Of The Texture and Quad
glEnd();

glEnable(GL_LIGHTING);

}

int BinCoef(int n, int k)
{
    if (k == 0 || k == n)
        return 1;
    return BinCoef(n - 1, k - 1) + BinCoef(n - 1, k);
}

float bezCurveY(float t2){//used to calculate y position
    float holder = 0;
    for(int i = 0; i < 3; i ++){

        holder += BinCoef(2, i) * pow(1-t2, 3 - 1 -i) * pow(t2, i) * clicks[i].y;
    }

    return holder;
}
float bezCurveZ(float t2){//used to calculate z position
    float holder = 0;
    for(int i = 0; i < 3; i ++){

        holder += BinCoef(2, i) * pow(1-t2, 3 - 1 -i) * pow(t2, i) * clicks[i].z;
    }

    return holder;
}


static void resize(int width, int height)
{
     double Ratio;

     Wwidth = (float)width;
     Wheight = (float)height;

     Ratio= (double)width /(double)height;

    glViewport(0,0,(GLsizei) width,(GLsizei) height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

	gluPerspective (45.0f,Ratio,0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

 }

static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

 //   glDisable(GL_DEPTH_TEST);
    gluLookAt(0,0,10.0,0.0,0.0,0.0,0.0,1.0,100.0);

    if(WireFrame)
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);		//Draw Our Mesh In Wireframe Mesh
	else
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);		//Toggle WIRE FRAME

    // your code here
    glPushMatrix();

    skyBox();
    glPopMatrix();



//glPointSize(2);
//making the path the character will follow although it still moved choppy
     glBegin(GL_POINTS);

    for (float t = 0; t<= 1; t+= 0.01){
        // (1-t)^2 p0 + 2(1-t)tp1+tp2
        //xpos = bezCurveX(t);//(1-t) * (1-t) * (1-t) * clicks[0].x + 3 * (1-t) * (1-t) * t* clicks[1].x + 3 * (1-t) * t * t * clicks[2].x + t * t * t * clicks[3].x;
        yposb = bezCurveY(t);//(1-t) * (1-t) * (1-t) * clicks[0].y + 3 * (1-t) * (1-t) * t* clicks[1].y + 3 * (1-t) * t * t * clicks[2].y + t * t * t * clicks[3].y;
        zposb = bezCurveZ(t);//(1-t) * (1-t) * (1-t) * clicks[0].z + 3 * (1-t) * (1-t) * t* clicks[1].z + 3 * (1-t) * t * t * clicks[2].z + t * t * t * clicks[3].z;

        //glVertex3f(0.0,yposb, zposb);
    }
    glEnd();


    //used to animate object along bezier curve
        //ballX = bezCurveX(t1);
        ballY = bezCurveY(t1);
        ballZ = bezCurveZ(t1);
    glPushMatrix();
        glTranslatef(0.0, 0.0, 1.5);
        glTranslatef(0.0, ballY, ballZ);
        wall();
    glPopMatrix();


    glutSwapBuffers();
}


void swapAB(float &A, float &B)
{

    float tmp;
    tmp = A;
    A = B;
    B = tmp;
}

static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
        case 27 :
        case 'q':
            exit(0);
            break;

	  case 'w':
		WireFrame =!WireFrame;
	       break;

      case 'a':
		xMin += 0.01;
		xMax += 0.01;
		xMin2 -= 0.01;
		xMax2 -= 0.01;

		 if(dirA){
            swapAB(xMaxP, xMinP);
            dirA = false;
        }
         if(clock()-startTime > 100){
            xMaxP++;
            xMinP++;

            xMaxC++;
            xMinC++;

            //put the bezier point creater here so that i will only generate points when moving the character and stop generating when not moving
            s+= 0.1;
            if(s >=1){
            //clicks[cnt].x = rand() % 9 - 5;
            clicks[cnt].y = rand() % 2-1;
            clicks[cnt].z = rand() % 2-1;
            cnt++;
            cnt = cnt%3;
            s = 0.0;
        }


            startTime = clock();

        }

        if(dirA2){
            swapAB(xMaxC, xMinC);
            dirA2 = false;
        }



	       break;

      case 'd':
		xMin -= 0.01;
		xMax -= 0.01;
		xMin2 += 0.01;
		xMax2 += 0.01;



         if(!dirA){
            swapAB(xMaxP, xMinP);
            dirA = true;
        }
        if(clock()-startTime > 100){
            xMaxP++;
            xMinP++;

            xMaxC++;
            xMinC++;

            //put the bezier point creater here so that i will only generate points when moving the character and stop generating when not moving
            s+= 0.1;
            if(s >=1){
            //clicks[cnt].x = rand() % 9 - 5;
            clicks[cnt].y = rand() % 2-1;
            clicks[cnt].z = rand() % 2-1;
            cnt++;
            cnt = cnt%3;
            s = 0.0;
        }

            startTime = clock();

        }

        if(!dirA2){
            swapAB(xMaxC, xMinC);
            dirA2 = true;
        }
	       break;

    }
}

void Specialkeys(int key, int x, int y)
{
    switch(key)
    {
    case GLUT_KEY_UP:
        thetaX +=5;
    break;

    case GLUT_KEY_DOWN:
        thetaX -=5;
    break;

    case GLUT_KEY_LEFT:
        thetaY +=5;
        break;

    case GLUT_KEY_RIGHT:
        thetaY -=5;
        break;
   }
  glutPostRedisplay();
}


static void idle(void)
{
    // Use parametric equation with t increment for xpos and y pos
    // Don't need a loop

    if(t1 < 1){//used to animate the object on its own
        t1+=0.006;

    }

    spin +=0.1;
    glutPostRedisplay();
}

void mouseMove(int x,int y)
{
    static float prev_x =0.0;
    static float prev_y =0.0;

    prev_x =(float)x-prev_x;
    prev_y =(float)y-prev_y;

    if((abs((int)prev_x)>15)||(abs((int)prev_y)>15))
    {
        prev_x = (float)x;
        prev_y = (float)y;
        return;
    }

    thetaX = (int)(thetaX + prev_y)%360;
    thetaY = (int)(thetaY + prev_x)%360;
}

void mouse(int btn, int state, int x, int y){

    float scale = 100*(Wwidth/Wheight);

    switch(btn){
        case GLUT_LEFT_BUTTON:

        if(state==GLUT_DOWN){

               // get new mouse coordinates for x,y
               // use scale to match right
            }
            break;
    }
     glutPostRedisplay();
};


static void init(void)
{
  //  glEnable(GL_CULL_FACE);
  //  glCullFace(GL_BACK);

    glewInit();

    glClearColor(0.5f, 0.5f, 1.0f, 0.0f);                 // assign a color you like

    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);

    glEnable(GL_DEPTH_TEST);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glShadeModel(GL_SMOOTH);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);

     glEnable(GL_TEXTURE_2D);
     glGenTextures(15, tex);

     TLoad("images/wall.jpg",tex[0]);
     TLoad("images/bottom.jpg",tex[1]);
     TLoad("images/parallax.jpg",tex[3]);
     TLoad("images/sprite.png",tex[4]);
     TLoad("images/top.jpg",tex[8]);
     TLoad("images/back.jpg",tex[9]);
     TLoad("images/left.jpg",tex[10]);
     TLoad("images/bottom.jpg",tex[11]);
     TLoad("images/right.jpg",tex[12]);
     TLoad("images/front.jpg",tex[13]);



     initShader("v1.vs","f1.fs", "g1.gs",program);

     glUseProgram(program);
     loc = glGetUniformLocation(program, "scale");

     if(loc != -1) glUniform1f(loc,anim);
     else cout << "scale value not found \n";
     glUseProgram(0);

     xMin = 0;
     xMax = 1;
     yMin = 0;
     yMax = 1;

    xMinP = 0;
    xMaxP = 1;
    yMinP = 0;
    yMaxP = 1;

    xMinC = 0;
    xMaxC = 1;
    yMinC = 0;
    yMaxC = 1;

    xMin2 = 0;
    xMax2 = 1;
    yMin2 = 0;
    yMax2 = 1;

    frames = 8.0;
    frames2 = 4.0;

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

/* Program entry point */

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);

    glutInitWindowSize(800,600);
    glutInitWindowPosition(0,0);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("Assignment 4: 2D animation");
    init();
    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(mouseMove);
    glutKeyboardFunc(key);
    glutSpecialFunc(Specialkeys);

    glutIdleFunc(idle);
    glutMainLoop();

    return EXIT_SUCCESS;
}
